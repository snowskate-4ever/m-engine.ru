# Чек-лист финальной проверки мессенджера и смежного окружения

Дата: 2026-03-29; **автотесты: полный прогон 2026-03-30**  
Связанные документы: `.cursor/docs/messenger-api.md`, `.cursor/plans/2026-03-29-messenger-roadmap.md`

Секреты в репозиторий не копировать — только проверка фактов на стенде.

---

## Как пользоваться чек-листом

| Режим | Когда | Что делать |
|--------|--------|------------|
| **Итерации / разработка** | Сейчас | Отмечайте только то, что нужно для текущей задачи. **Полный прогон тестов и «зачеркнуть весь документ» не обязательны.** |
| **Предрелизный gate** | Перед выкладкой в прод | Пройти **все** применимые разделы (1–7) и блок **«Отложено ранее»**; зафиксировать дату прогона в конце файла. |

**Сознательно отложено на более поздний момент (до предрелизного gate):**

- **CI** с полным `php artisan test` на каждый PR — если ещё не настроен, сделать в pipeline отдельно (локальный полный прогон зафиксирован в §0 / §8 от **2026-03-30**);
- полный **ручной smoke** по всем пунктам §3–§6 за один проход;
- вычёркивание **всех** чекбоксов в этом файле.

Это нормальная схема работы, если осознанно возвращаетесь к gate перед продом.

---

## 0. Отложено ранее — выполнить перед продакшеном

- [x] `php artisan test` — **локально 2026-03-30: полный suite** — **103 passed**, **283 assertions** (`APP_ENV=testing`, SQLite `:memory:` по `phpunit.xml`). В т.ч.: Unit (`AiRruleNextOccurrenceServiceTest`, `ExampleTest`); Feature **Ai** (`AgentToolExecutorTest`, `AiBillingSubscriptionTest`); **ApiFeaturesTest**; **Auth** (Fortify + `MultiChannelAuthTest`); **Messenger** (`MessengerApiTest`, `MessengerBroadcastTest`, `MessengerPushTest`, `MessengerRetentionPruneTest`, `MessengerWebUiTest`); **Settings** (профиль, пароль, 2FA); `DashboardTest`, `Feature/ExampleTest`. См. таблицу в `.cursor/plans/2026-03-29-messenger-roadmap.md` (§10).
- [ ] Пройти **полностью** §3–§6 этого файла (ручной smoke) или эквивалент в тестовой сборке приложения
- [x] Дата прогона (автоматика): **2026-03-30**

---

## 1. Код и автоматические проверки (gate)

- [x] `./vendor/bin/pint --test` — **для связки мессенджера/ИИ** (см. §8): без замечаний. Полный `pint --test` по всему репо: **~194 файла с замечаниями** (legacy), к gate мессенджера не относится.
- [x] `php artisan test` — см. §0 *(полный suite, 103 теста)*
- [x] `php artisan route:list --path=api/messenger` — **16** маршрутов (в т.ч. `presence`, skills)
- [x] `php artisan route:list --path=api/ai` — **9** маршрутов
- [x] `php artisan migrate --force` — **локально:** применена отложенная `2026_03_30_160000_billing_idempotency_and_ai_log_full_content`; на **проде** выполнить тот же migrate перед релизом

---

## 2. Переменные окружения (минимум)

### Приложение

- [ ] `APP_URL` совпадает с тем, что видят клиенты (веб: `https://m-engine.ru` или ваш домен)
- [ ] `APP_DEBUG=false` на проде
- [ ] `APP_KEY` задан и **не меняется** без плана (BYOK и `encrypted` в БД)

### База и очереди

- [ ] `DB_*` — рабочее подключение
- [ ] Очередь (`QUEUE_CONNECTION`) и воркер `queue:work` / supervisor — задачи уходят из очереди
- [ ] **Ответы AI:** job `ProcessAiChatReplyJob` обрабатывается воркером (на проде **не** полагаться только на `sync`)

### Sanctum / API для мобильных

- [ ] Токены выдаются и принимаются в `Authorization: Bearer …`
- [ ] При необходимости: `SANCTUM_STATEFUL_DOMAINS` для веба

### Мессенджер (`config/messenger.php`)

- [ ] `MESSENGER_MAX_ATTACHMENT_BYTES` — если нужен лимит размера вложения
- [ ] `MESSENGER_ALLOWED_MIMES` — если нужен whitelist MIME
- [ ] `MESSENGER_MAX_ATTACHMENTS_PER_MESSAGE` — если нужен лимит числа файлов

### Reverb / WebSocket

- [ ] `REVERB_*` / `VITE_REVERB_*` согласованы с фронтом
- [ ] Процесс `php artisan reverb:start` (или сервис) запущен на сервере
- [ ] Браузер/клиент подключается к `wss://…`, канал `private-messenger.conversation.{id}` авторизуется (`/broadcasting/auth`)

### Push (FCM и при необходимости APNs)

- [ ] `FCM_LEGACY_SERVER_KEY` (или актуальный ключ по вашей схеме) задан, если push должен реально уходить
- [ ] `POST /api/devices/push-token` с реального приложения сохраняет строку в `device_push_tokens`
- [ ] Новое сообщение в тестовом чате ставит job и (при валидном ключе) доставляет уведомление; при пустом ключе — осознанный no-op

### ИИ (`config/ai.php` + БД)

- [ ] `AI_MASTER_ENABLED` — при `false`: **`POST /api/messenger/conversations`** с `type=ai` → **422** (поле `type`); маршруты под **`ai.enabled`** (`/api/ai/*`, скилы) → **503** `{ "code": "ai_disabled" }`
- [ ] `AI_OPENAI_SERVER_API_KEY` и/или **`api_key` в `ai_providers.config`** для серверных моделей
- [ ] В БД есть **активный** `ai_provider` (driver `openai`) и **активная** `ai_server_model`, либо пользователи создают чаты только с **BYOK** (`user_ai_connection_id`)
- [ ] `AI_REQUEST_LOG_RETENTION_DAYS` при необходимости переопределён
- [ ] Планировщик вызывает `ai:prune-request-logs` (или команда прогнана вручную на стенде)
- [ ] Опционально локально: `php artisan db:seed --class=AiDemoSeeder` — демо-провайдер/модель (только `local`)

### Биллинг серверного ИИ (`config/billing.php`)

- [ ] `BILLING_AI_QUOTA_TIMEZONE` (по умолчанию Europe/Moscow), `BILLING_AI_TRIAL_*`, `BILLING_AI_UNPAID_DAILY_ALLOWANCE` согласованы с продуктом
- [ ] Для платящих/ручной выдачи: `users.ai_subscription_valid_until` при необходимости выставлен (Moonshine/SQL)
- [ ] После исчерпания дневного лимита второе сообщение в **серверный** AI-чат даёт системное сообщение о лимите; BYOK не считается

### Moonshine (ИИ + мессенджер)

- [ ] Группа «Мессенджер»: чаты и сообщения открываются
- [ ] Группа «ИИ» → журнал запросов открывается (admin/editor на просмотр)
- [ ] Кнопка **Экспорт CSV** на индексе журнала — только **admin**, файл до 50k строк

---

## 3. Функциональная проверка API мессенджера (ручной smoke)

По сценариям из `.cursor/docs/messenger-api.md` *(можно отложить до §0)*:

- [ ] `GET /api/messenger/preferences` / `PATCH` — глобальный push on/off
- [ ] `POST /api/messenger/conversations` — direct и group; повтор direct на ту же пару возвращает тот же `id`
- [ ] **`POST` AI-чат** — `type=ai`, `title`, ровно одно из `ai_server_model_id` / `user_ai_connection_id`; при выключенном мастер-флаге — **422** на `type` («AI is disabled.»)
- [ ] **`POST …/messages` в AI-чате** — после воркера очереди появляется ответ с `user_id: null` (или системное сообщение об ошибке); в Echo событие `messenger.message.sent` для ответа ИИ приходит без лишней очереди broadcast
- [ ] **Веб / AI** — после отправки текста в AI-чате ускоренный poll и подсказка «ожидаем ответ»; при подключённом Echo список обновляется по событию
- [ ] **Веб / скилы** — в AI-чате блок скилов: добавить / редактировать / вкл-выкл / удалить (свои), лимит из `config/ai.php`
- [ ] `GET` список чатов, `GET` деталь (в т.ч. поля `ai_server_model_id` / `user_ai_connection_id` для `type=ai`), **403** для неучастника
- [ ] `PATCH` retention: группа только owner; direct — оба участника; **AI** — retention по-прежнему с ограничениями в коде
- [ ] `GET …/messages` — первая страница, `before_id` / `after_id`, ошибка при двух курсорах
- [ ] `POST …/messages` — текст, multipart с вложениями, `client_message_id` (повтор без дубля)
- [ ] Вложения: в JSON есть `download_url`; **GET** по нему без Bearer отдаёт файл до истечения TTL; после `expires` — снова список/история сообщений
- [ ] Пересылка: `forward_from_message_id`, без вложений в том же запросе
- [ ] `POST …/read`, `PATCH …/notifications` (mute / mute_until)
- [ ] **Скилы AI-чата** (при `AI_MASTER_ENABLED=true`): `GET/POST/PATCH/DELETE …/conversations/{id}/skills` — только `type=ai`, правки только своих скилов

---

## 4. API ИИ (`/api/ai/*`) *(можно отложить до §0)*

- [ ] `GET /api/ai/server-models` — список активных моделей (пустой, пока не засеяли БД)
- [ ] `GET|POST|PATCH|DELETE /api/ai/connections` — BYOK; в ответах только `key_hint`, не полный ключ
- [ ] При `AI_MASTER_ENABLED=false` — **503** `{ "code": "ai_disabled" }` на защищённых AI-маршрутах

---

## 5. Веб (Livewire)

- [ ] `/messenger` — список и переход в комнату
- [ ] Отправка текста и (если есть в UI) файла
- [ ] Echo: новое сообщение с другого клиента появляется без перезагрузки
- [ ] Экран настроек уведомлений синхронен с API preferences
- [ ] **AI-чат в UI** — по плану отдельной итерации (если ещё не сделано)

---

## 6. Надёжность и мобильные (из плана)

- [ ] Базовый URL: список IP + fallback на домен — проверен в тестовой сборке приложения
- [ ] После обрыва WS — догон `GET …/messages?after_id=…`
- [ ] Идемпотентная отправка с `client_message_id` проверена на дубликат запроса

---

## 7. Постдеплой

- [ ] `php artisan storage:link` если используете публичные файлы из `storage/app/public`
- [ ] Логи (`storage/logs`) без необработанных исключений при типовых действиях
- [ ] Резервное копирование БД по вашей политике

---

*В конце предрелизного gate: дата в §0, при использовании CI — ссылка на успешный pipeline.*

---

## 8. Журнал автоматических прогонов

| Когда | Что сделано |
|--------|-------------|
| 2026-03-30 | `migrate --force`: billing idempotency + AI log full content |
| 2026-03-30 | Тесты: `Messenger/*`, `Ai/*`, `ApiFeaturesTest` — 59 passed *(частичный прогон)* |
| 2026-03-30 | **`php artisan test` — полный suite репозитория: 103 passed, 283 assertions** (включая Auth/Settings и Unit RRULE) |
| 2026-03-30 | `pint --test` на наборах: `app/Services/Messenger`, контроллеры messenger/skills/attachments, `app/Livewire/Messenger`, `tests/Feature/Messenger`, `tests/Feature/Ai`, `ApiFeaturesTest`, jobs push + `ProcessAiChatReplyJob` — PASS; автофикс: `MessengerService.php`, `AiBillingSubscriptionTest.php` |
| 2026-03-30 | Планировщик (`bootstrap/app.php`): `messenger:prune-retention` 03:30, `ai:prune-request-logs` 04:00, `ai:process-scheduled-items` every minute |

**Остаётся только на стенде/проде (не из IDE):** §2 (env, Reverb, FCM/APNs, Moonshine вручную), §3–§6 smoke, §7 постдеплой.
