# Настройка отправки почты через очередь Laravel (m-engine)

Инструкция для продакшена и локальной отладки: письма (в т.ч. напоминания из §17 плана мессенджера) уходят **асинхронно** через **queue worker**, а не в том же HTTP-запросе.

---

## 1. Переменные `.env`

```env
MAIL_MAILER=smtp
MAIL_HOST=...
MAIL_PORT=587
MAIL_USERNAME=...
MAIL_PASSWORD=...
MAIL_ENCRYPTION=tls
MAIL_FROM_ADDRESS="noreply@m-engine.ru"
MAIL_FROM_NAME="M-Engine"

# Очередь: для старта можно database; для нагрузки — redis
QUEUE_CONNECTION=database
```

Для **Redis** (после установки `predis`/`phpredis` и настройки `REDIS_*`):

```env
QUEUE_CONNECTION=redis
```

---

## 2. Таблица очереди (driver `database`)

```bash
php artisan queue:table
php artisan migrate
```

Убедиться, что в `config/queue.php` для `database` указано корректное соединение.

---

## 3. Классы писем

- Наследовать **`Illuminate\Mail\Mailable`** и реализовать интерфейс **`Illuminate\Contracts\Queue\ShouldQueue`** (или использовать **`Notification`** с каналом `mail` + **`ShouldQueue`**).
- Не вызывать `Mail::send()` синхронно в коде напоминаний — только `Mail::queue()`, `->queue()`, `Notification::send()` с очередью или диспатч `SendQueuedMailable`.

Пример (идея):

```php
final class AiReminderMail extends Mailable implements ShouldQueue
{
    use Queueable, SerializesModels;

    public function __construct(public AiScheduledItemDto $payload) {}

    public function envelope(): Envelope
    {
        return new Envelope(subject: $this->payload->title);
    }

    public function content(): Content
    {
        return new Content(view: 'mail.ai-reminder');
    }
}
```

---

## 4. Запуск воркера

**Разработка:**

```bash
php artisan queue:work --tries=3
```

Удобно вместе с `composer dev`, если добавить отдельный процесс в `concurrently`.

**Продакшен:** постоянный процесс (Supervisor, systemd, Docker sidecar) с той же командой и перезапуском при падении.

Пример unit для **Supervisor** (путь и пользователь подставить свои):

```ini
[program:m-engine-queue]
process_name=%(program_name)s_%(process_num)02d
command=php /var/www/m-engine.ru/artisan queue:work redis --sleep=3 --tries=3 --max-time=3600
autostart=true
autorestart=true
user=www-data
numprocs=1
redirect_stderr=true
stdout_logfile=/var/log/m-engine-queue.log
```

---

## 5. Планировщик Laravel

Крон на сервере **одна строка**:

```text
* * * * * cd /path-to-project && php artisan schedule:run >> /dev/null 2>&1
```

Напоминания (`user_ai_scheduled_items`) обрабатываются в `app/Console/Kernel.php` (или `routes/console.php` в Laravel 11+) через `Schedule::command(...)` или вызов класса — см. план §17.

---

## 6. Неудачные задачи

```bash
php artisan queue:failed
php artisan queue:retry all
```

Таблица `failed_jobs` при `database` — миграция `php artisan queue:failed-table` при необходимости.

---

## 7. Проверка

1. `QUEUE_CONNECTION=database` (или `redis`), миграции применены.  
2. Воркер запущен.  
3. Тестовое письмо через tinker: `Mail::to(...)->queue(new SomeMailable)`.  
4. В логах нет синхронной отправки в web-процессе для тяжёлых сценариев.

---

## 8. Опционально: Laravel Horizon

При `redis` можно подключить **Horizon** для мониторинга очередей (отдельная настройка и авторизация дашборда).

---

Связь с продуктом: `.cursor/plans/2026-03-29-messenger-roadmap.md` (§17 — email-напоминания).
