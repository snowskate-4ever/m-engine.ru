# Биллинг и квоты серверного ИИ

Конфиг: `config/billing.php`, переменные окружения ниже. **BYOK** (`user_ai_connection_id`) эти лимиты **не** использует.

## Поведение (приоритет сверху вниз)

1. **Активная подписка в БД** (`user_ai_subscriptions`: `status = active`, `current_period_end > now`), тариф `ai_subscription_tiers`:
   - `limits.server_requests_per_day` **отсутствует или `null`** — без дневного лимита **со стороны тарифа** (счётчик в `user_ai_server_day_usages` не растёт **только** из‑за тарифа; см. п. 4).
   - `limits.server_requests_per_day` **число** — столько успешных серверных запросов за календарные сутки (таймзона из `billing.quota_timezone`), счётчик в `user_ai_server_day_usages`.
   - `limits.allowed_ai_server_model_ids` **отсутствует** — разрешены все серверные модели (и в `GET /api/ai/server-models`, и при вызове).
   - **Пустой массив** `allowed_ai_server_model_ids` — ни одна серверная модель не разрешена.
   - **Непустой массив** — только перечисленные `id` из `ai_server_models`.
   - **`server_tokens_per_month`** (число) — сумма `tokens_prompt + tokens_completion` в **`ai_usage_ledger`** за **календарный месяц** в `billing.quota_timezone`; проверка перед серверным вызовом; `null`/отсутствует — без месячного лимита.
   - **`max_ai_chats`** — максимум чатов `conversations.type = ai`, где пользователь участник; проверка при `POST /api/messenger/conversations` с `type: ai`.
   - **`tools_enabled`** = `false` — в **серверных** AI-чатах инструменты агента (OpenAI `tools`) **не** передаются; BYOK не затрагивается.
2. **Наследие:** `users.ai_subscription_valid_until` в будущем **и нет активной подписки п.1** — без дневного лимита (как раньше).
3. **Триал / неплатящий:** с первого **успешного** ответа серверной модели ставится `ai_trial_started_at`; в окне триала — `trial_max_requests_per_day` за сутки (МСК); после триала без подписки — `unpaid_daily_server_request_allowance`.
4. **Self-cap:** таблица `user_ai_preferences` (`max_requests_per_day_self` nullable). Эффективный дневной лимит = **min**(`server_side_daily_ceiling`, self-cap), если self-cap задан; при «безлимитном» тарифе и заданном self-cap учёт в `user_ai_server_day_usages` **ведётся**. Верхняя граница self-cap при отсутствии тарифного потолка: `billing.max_self_cap_requests_per_day` (env `BILLING_AI_MAX_SELF_CAP_PER_DAY`).

Учёт успешных запросов: таблица `user_ai_server_day_usages` (`user_id`, `usage_date`, `request_count`). Увеличение **только** после успешного ответа провайдера, если эффективный дневной лимит **не** `null`.

Проверки квот: **до отправки** сообщения — в `MessengerService` (синхронный ответ API с `{ code, message }`); повторно в `AiMessengerReplyService` для защиты от обхода очереди. В чат по-прежнему пишутся локализованные системные сообщения, если отказ случился **после** приёма сообщения (например устаревшая квота между приёмом и job).

Сервис: `AiServerQuotaService` (`serverSideDailyCeiling`, `effectiveServerDailyRequestLimit`, `getServerRequestsUsedToday`, `allowedServerModelIdsForApi`).

## Учёт токенов (ledger)

После каждого **успешного** вызова пишется строка в **`ai_usage_ledger`** (`AiUsageLedgerWriter`): для **сервера** — `source = server`, для **BYOK** — `source = byok` (модель в ledger `null`), токены, `conversation_id`, оценка себестоимости для server при наличии полей модели.

В **`ai_request_logs`** при успехе поле **`estimated_internal_cost`** заполняется **той же** формулой, что и в ledger (см. `AiUsageLedgerWriter::estimateServerInternalCost`).

Moonshine: **`AiUsageLedgerResource`** (просмотр), на дашборде — метрики «токены за месяц» и сумма оценки расхода по ledger (`App\MoonShine\Pages\Dashboard`).

## Аудит команд агента (§14)

Таблица **`agent_tool_invocations`**: пользователь, чат, имя tool, хэш аргументов, успех, текст ошибки. Запись из **`AgentToolExecutor`** после каждого вызова. Moonshine: **`AgentToolInvocationResource`**.

## BYOK — rate limit

`config('ai.byok.max_requests_per_minute')` (`AI_BYOK_MAX_REQUESTS_PER_MINUTE`), `0` = выкл. Скользящее окно 60 с на пользователя. Учёт попаданий — при **успешной** записи исходящего сообщения в `MessengerService` (согласовано с предпроверкой `POST .../messages`).

## API

- **`GET /api/ai/subscription`** (Sanctum, middleware `ai.enabled`) — подписка, `preferences`, квота за текущие сутки и месячные токены, `legacy_subscription_valid_until`, блок **`client_hints`**: `needs_subscription`, `server_ai_available` (опционально уточнить query `ai_server_model_id`).
- **`PATCH /api/ai/preferences`** — `max_requests_per_day_self` (см. `.cursor/docs/messenger-api.md`).

## Платежи (расширение)

- Интерфейс **`App\Contracts\Billing\PaymentGatewayContract`**. Реализации: **`StubBillingPaymentGateway`** (`stub`), **`YooKassaPaymentGateway`** (`yookassa`). Выбор: env **`BILLING_PAYMENT_GATEWAY`** (`stub` \| `yookassa`), конфиг `billing.payment_gateway`.

## Webhook-заглушка

- **`POST /api/webhooks/billing/stub`** — тело JSON, подпись **`X-Billing-Signature`** = `hash_hmac('sha256', raw_body, secret)`.
- Секрет: **`BILLING_WEBHOOK_SECRET`** в `.env`, ключ конфига `billing.webhook_secret`. Пустой секрет — **403**.
- Пример тела: `user_id`, `tier_slug` (активный тариф), `current_period_end` (ISO 8601), опционально `current_period_start`, `payment_provider`, `external_payment_ref`, `sync_user_valid_until` (bool, по умолчанию обновляет `users.ai_subscription_valid_until`), опционально **`webhook_event_id`** — повтор с тем же id возвращает тот же `subscription_id` без второй записи (`deduplicated: true`).
- Сервис: `BillingSubscriptionSyncService::applyFromStubPayload` — при **новом** `external_payment_ref` отменяет прочие активные подписки пользователя и создаёт запись; повтор того же `(payment_provider, external_payment_ref)` **обновляет** существующую строку (идемпотентность).

## Webhook ЮKassa

- **`POST /api/webhooks/billing/yookassa`** — тело уведомления ЮKassa (`event` = `payment.succeeded`, `object.id` = id платежа).
- Сервер запрашивает **`GET https://api.yookassa.ru/v3/payments/{id}`** с Basic Auth **`shopId:secretKey`** (`YOOKASSA_SHOP_ID`, `YOOKASSA_SECRET_KEY`) и при `status: succeeded` читает **metadata**: обязательны `user_id`, `tier_slug`, `current_period_end`; опционально `current_period_start`.
- Идемпотентность по id платежа (кэш + уникальность пары провайдер / внешний ref в БД).
- Создание платежа на стороне магазина и передача metadata — вне этого репозитория; см. [документацию ЮKassa](https://yookassa.ru/developers/api).

## Админка (Moonshine)

- Тарифы: **`AiSubscriptionTierResource`**
- Подписки пользователей: **`UserAiSubscriptionResource`**

## Переменные `.env`

| Ключ | Назначение |
|------|------------|
| `BILLING_AI_QUOTA_TIMEZONE` | Таймзона границы суток (по умолчанию `Europe/Moscow`) |
| `BILLING_AI_TRIAL_DAYS` | Длительность триала, дней |
| `BILLING_AI_TRIAL_MAX_REQUESTS_PER_DAY` | Потолок успешных запросов в сутки в окне триала |
| `BILLING_AI_UNPAID_DAILY_ALLOWANCE` | Потолок после триала без подписки (`0` = только подписка) |
| `BILLING_WEBHOOK_SECRET` | Секрет HMAC для `/api/webhooks/billing/stub` |
| `BILLING_WEBHOOK_EVENT_TTL` | TTL кэша идемпотентности `webhook_event_id` / ЮKassa payment id, сек (по умолчанию 30 суток) |
| `BILLING_PAYMENT_GATEWAY` | `stub` или `yookassa` |
| `YOOKASSA_SHOP_ID`, `YOOKASSA_SECRET_KEY` | Доступ к API ЮKassa для webhook |
| `BILLING_AI_MAX_SELF_CAP_PER_DAY` | Макс. добровольный дневной лимит, если у тарифа нет потолка (по умолчанию 100000) |
| `AI_REQUEST_LOG_STORE_FULL_PROMPT`, `AI_REQUEST_LOG_STORE_FULL_RESPONSE` | Полный промпт/ответ в `ai_request_logs` (осторожно с ПДн; см. `config/ai.php`) |
| `AI_REQUEST_LOG_FULL_CONTENT_RETENTION_DAYS` | Через сколько дней обнулять `prompt_full`/`response_full` (команда `ai:prune-request-logs`) |

## Коды ошибок

- `quota_exceeded` — дневной лимит серверного ИИ или BYOK rate limit (в API мессенджера — HTTP **402**).
- `token_quota_exceeded` — месячный лимит токенов (**402**).
- `subscription_required` — модель не входит в тариф (**403**; внутри сервиса по-прежнему `model_not_in_plan`).
- `ai_disabled` — выключен мастер-флаг ИИ (**503** на `/api/ai/*`).

См. также `.cursor/rules/ai-subscription-quotas.mdc` и план §15.
