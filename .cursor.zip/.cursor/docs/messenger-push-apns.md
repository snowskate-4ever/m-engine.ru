# Push: APNs (iOS) рядом с FCM (Android)

Документ фиксирует **реализацию в репозитории** и шаги для эксплуатации. Общий план мессенджера: `.cursor/plans/2026-03-29-messenger-roadmap.md` §7.

## Роли транспортов

| `platform` в `POST /api/devices/push-token` | Транспорт | Когда шлём |
|---------------------------------------------|-----------|------------|
| `android` | **FCM** legacy HTTP (`messenger.fcm.legacy_server_key`) | Ключ задан в `.env` |
| `ios` | **APNs** HTTP/2, JWT (.p8) | Заданы `APNS_*` (см. ниже) |

Job `SendMessengerPushNotificationsJob` **не выходит сразу**, если настроен **хотя бы один** из каналов (FCM или APNs). Для каждого токена выбирается свой отправитель.

## Что нужно от Apple

1. **Apple Developer** → Keys → создать ключ с capability **Apple Push Notifications service (APNs)**.
2. Скачать **`AuthKey_XXXXXX.p8`** (один раз), запомнить **Key ID** и **Team ID**.
3. **Bundle ID** iOS-приложения (тот же, что в Xcode) — это **topic** для заголовка `apns-topic`.

Сертификат-based (.pem) в текущей реализации **не используется** — только token auth (.p8 + JWT).

## Переменные окружения

| Переменная | Обязательность | Описание |
|------------|----------------|----------|
| `APNS_TEAM_ID` | Да, для APNs | 10 символов, Team ID |
| `APNS_KEY_ID` | Да | Key ID ключа APNs |
| `APNS_AUTH_KEY_PATH` | Да* | Абсолютный или относительный путь к `.p8` на сервере |
| `APNS_BUNDLE_ID` | Да | Bundle ID приложения (например `ru.m-engine.app`) |
| `APNS_USE_SANDBOX` | Нет | `true` — `api.sandbox.push.apple.com` (debug-сборки); иначе production |
| `APNS_HTTP_TIMEOUT` | Нет | Таймаут HTTP, секунды (см. `config/messenger.php`) |

\* Путь должен быть читаем процессом PHP (воркер очереди).

`FCM_LEGACY_SERVER_KEY` по-прежнему для Android; можно настроить **только APNs**, **только FCM** или оба.

## Формат device token (iOS)

Нативное приложение должно передавать **device token APNs** в том виде, в котором его удобно сложить в URL Apple (обычно **строка из 64 шестнадцатеричных символов** без пробелов). Сервер нормализует: убирает не-hex символы и приводит к нижнему регистру.

Если клиент шлёт токен в другом формате (например с пробелами из `description`) — после нормализации он должен стать 64 hex.

## HTTP-контракт APNs (кратко)

- **Production:** `POST https://api.push.apple.com/3/device/{device_token_hex}`
- **Sandbox:** `POST https://api.sandbox.push.apple.com/3/device/{device_token_hex}`
- Заголовки: `authorization: bearer <JWT>`, `apns-topic`, `apns-push-type: alert`, `apns-priority: 10`
- Тело: JSON с `aps.alert.title` / `aps.alert.body`, `aps.sound`, плюс кастомные поля (`type`, `conversation_id`, `message_id`) на корне payload (как в FCM `data`).

JWT: алгоритм **ES256**, claims `iss` (Team ID), `iat`, заголовок `kid` (Key ID). Подпись ключом из `.p8`.

## Зависимости PHP

- Пакет **`firebase/php-jwt`** — подпись JWT ES256.
- **HTTP/2:** клиент Laravel использует Guzzle/cURL; на сервере нужен **cURL с поддержкой HTTP/2** (типичный Linux-образ с пакетом `curl`/`libcurl` с nghttp2). На Windows в dev возможны ограничения — проверять логи `messenger.apns_http_error`.

## Ошибки и удаление токена

При ответах **410 Gone** или **400** с телом `reason` из множества `BadDeviceToken`, `Unregistered`, `DeviceTokenNotForTopic` запись в `device_push_tokens` **удаляется** (аналогично мёртвым FCM-токенам).

## Тесты

Фикстура **`tests/fixtures/apns_test_auth_key.p8`** — тестовый EC-ключ (источник: репозиторий [edamov/pushok](https://github.com/edamov/pushok), только для **локальных тестов**, не для продакшена). В feature-тестах выставляется `config(['messenger.apns' => ...])` и `Http::fake` на хост Apple.

## Связанные файлы

- `config/messenger.php` — секция `apns`
- `app/Services/Push/ApnsPushSender.php`
- `app/Services/Push/FcmLegacyPushSender.php`
- `app/Jobs/SendMessengerPushNotificationsJob.php`
- `.cursor/docs/messenger-api.md` — регистрация токена и базовый URL API
