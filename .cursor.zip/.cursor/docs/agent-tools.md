# ИИ-агент: команды (tools) vs пользовательские скилы

См. план `.cursor/plans/2026-03-29-messenger-roadmap.md` §14, §17, §19. Правило паритета: `.cursor/rules/agent-service-parity.mdc`.

## Терминология

| Термин | Значение |
|--------|----------|
| **Скил** | Текст пользователя в AI-чате (`user_ai_chat_skills`), подмешивается в system prompt. |
| **Команда / tool** | Зарегистрированная функция с JSON Schema; модель вызывает через OpenAI `tool_calls`. |

## Где в коде

| Компонент | Путь |
|-----------|------|
| Реестр определений tools | `app/Services/Agent/AgentToolRegistry.php` |
| Исполнение (проверка владельца, запись в БД) | `app/Services/Agent/AgentToolExecutor.php` |
| Парсинг дат (МСК по умолчанию) | `app/Services/Agent/AiScheduledItemTimeParser.php` |
| Цикл `tool_calls` в чате | `app/Services/Ai/AiChatToolLoop.php` |
| HTTP к провайдеру | `app/Services/Ai/OpenAiChatCompletionClient.php` |
| Включение / лимит раундов | `config/ai.php` → `agent.*`, env `AI_AGENT_TOOLS_ENABLED`, `AI_AGENT_MAX_TOOL_ROUNDS` |

## Список tools (v1)

### `schedule_reminder`

Создаёт строку в `user_ai_scheduled_items` (`kind=task_reminder`).  
Аргументы: `title`, `fire_at` (ISO; без таймзоны = **Europe/Moscow**), опционально `repeat_rule` (фрагмент RRULE, напр. `FREQ=DAILY;INTERVAL=1`), `notify_push`, `notify_email`.

### `create_task_with_deadline`

Создаёт `tasks` для пользователя. Аргументы: `name`, `deadline_at`, опционально `description`. Срок дублируется в тексте описания задачи.

### `link_event_booking_reminder`

Проверяет, что `events.id` принадлежит пользователю, и создаёт напоминание (`kind=event_booking`) на `remind_at`.

## Напоминания и доставка

- Таблица **`user_ai_scheduled_items`**: `next_fire_at` (UTC), `repeat_rule`, каналы `notify_push` / `notify_email`.
- Команда **`php artisan ai:process-scheduled-items`** (по расписанию каждую минуту): переводит просроченные `pending` → `processing`, ставит **`DeliverUserAiScheduledItemJob`**.
- Job: push через **`UserDirectPushService`** (учитывает глобальный `messenger_push_enabled`); письмо **`AiScheduledReminderMail`** (очередь) только при **`email_verified_at`**.
- Повторы: **`AiRruleNextOccurrenceService`** + библиотека **`rlanvin/php-rrule`**; якорь `payload.rrule_anchor_utc`.

## API для пользователя

| Метод | Путь | Описание |
|--------|------|----------|
| `GET` | `/api/ai/scheduled-items` | Свои пункты (до 200), middleware `auth:sanctum` + `ai.enabled` |
| `DELETE` | `/api/ai/scheduled-items/{id}` | Отмена / удаление своей записи |

## Квоты

Вызовы модели с tools расходуют те же квоты, что и обычный ответ в AI-чате (серверный ключ / BYOK). Сами tools **не** делают дополнительного платного вызова API, кроме следующих раундов чата, пока модель отвечает.

## Аудит

Структурированный лог: `agent.tool_call` и `agent.tool_failed` (см. `AgentToolExecutor`).
