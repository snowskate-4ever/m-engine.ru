# API мессенджера (мобильные клиенты и интеграции)

Документ описывает **текущий** серверный контракт по коду Laravel. Префикс версии (`/api/messenger/v1/...`) **пока не используется**; при ломающих изменениях планируется ввести версионирование (см. `.cursor/plans/2026-03-29-messenger-roadmap.md`).

**Обновлено:** 2026-03-29 (квоты ИИ в ответе `POST .../messages`, presence, `client_hints` в подписке, ЮKassa webhook).

Синхронное развитие веб/API: `.cursor/rules/messenger-sync.mdc`.

---

## Базовый URL и авторизация

| Параметр | Значение |
|----------|----------|
| База API | `{BASE}/api`, где `{BASE}` — `https://m-engine.ru` (веб) или IP из списка эндпоинтов приложения с fallback на домен |
| Защита | `Authorization: Bearer {token}` (Laravel Sanctum personal access token или совместимый токен, выданный вашим потоком логина) |
| Формат | JSON, кодировка UTF-8 |
| Ошибки валидации Laravel | HTTP **422**, тело с полем `errors` (стандарт Laravel) или для отдельных проверок — объект с ключом `message` (см. ниже) |

Неавторизованный доступ к защищённым маршрутам: **401**.

Доступ к чужому чату (не участник): **403** (`ConversationPolicy::view`).

### Стабильные отказы по квотам / подписке ИИ (JSON)

Для **`POST /api/messenger/conversations/{id}/messages`** в чате **`type=ai`**, если сообщение **запускает** серверный или BYOK-ответ (текст без вложений, не пересылка), сервер выполняет **предпроверку** до записи сообщения. Тело ответа:

```json
{ "code": "<строка>", "message": "<человекочитаемый текст>" }
```

| HTTP | `code` | Когда |
|------|--------|--------|
| **402** | `quota_exceeded` | Дневной лимит серверного ИИ или BYOK rate limit (`AI_BYOK_MAX_REQUESTS_PER_MINUTE`) |
| **402** | `token_quota_exceeded` | Месячный лимит токенов тарифа |
| **403** | `subscription_required` | Модель не входит в тариф (ранее `model_not_in_plan` внутри сервиса) |
| **503** | `ai_disabled` | Middleware `ai.enabled` на маршрутах `/api/ai/*` (см. ниже) |

Для маршрутов с middleware **`ai.enabled`** при выключенном ИИ: **503** и тот же формат с `code: ai_disabled`. Подробнее про квоты — **`.cursor/docs/ai-billing.md`**.

### Публичные эндпоинты (без Bearer)

#### `GET /api/features`

**200** — глобальные переключатели для клиентов (в т.ч. до авторизации):

```json
{
  "data": {
    "ai_enabled": true,
    "ai_api_version": "1"
  }
}
```

`ai_enabled` соответствует `config('ai.enabled')` / `AI_MASTER_ENABLED`. Используйте для скрытия экранов ИИ. Флаги «нужна ли подписка» / «доступен ли серверный ИИ» для **конкретного пользователя** — в **`GET /api/ai/subscription`** (`client_hints`, см. раздел API ИИ).

---

## Типы и перечисления

### `conversation.type`

| Значение | Описание |
|----------|----------|
| `direct` | Личный чат между двумя пользователями |
| `group` | Группа |
| `ai` | Чат с моделью: один участник — пользователь; ответы ассистента в истории с `user_id: null` (см. ниже) |

### `message.kind`

| Значение | Описание |
|----------|----------|
| `text` | Текст (в т.ч. сообщение только с подписью к пересылке) |
| `file` | Есть вложения |
| `system` | Системные сообщения (при необходимости в будущем) |

### `push` — регистрация токена

Поле `platform`: **`ios`** | **`android`** (строго эти строки).

---

## Общие структуры JSON

### Объект сообщения (`message`)

Используется в списках, деталях чата и в broadcast `messenger.message.sent`.

| Поле | Тип | Описание |
|------|-----|----------|
| `id` | int | Идентификатор сообщения |
| `conversation_id` | int | Чат |
| `user_id` | int \| null | Автор; **`null`** — ответ ассистента в чате `type=ai` и прочие системные случаи без пользователя |
| `author` | `{ id, name }` \| null | Дублирует автора для UI |
| `kind` | string | См. `message.kind` |
| `body` | string \| null | Текст |
| `is_forward` | bool | Признак пересылки |
| `forwarded_from_message_id` | int \| null | Исходное сообщение в другом чате |
| `forward_snapshot` | object \| null | Снимок на момент пересылки (текст, kind, `source_conversation_id`, `author`, урезанные данные вложений) |
| `client_message_id` | string (UUID) \| null | Идемпотентность отправки |
| `created_at` | string | ISO 8601 |
| `attachments` | array | См. ниже |

### Вложение в сообщении

| Поле | Тип | Описание |
|------|-----|----------|
| `id` | int | id записи |
| `disk` | string | Имя диска Laravel (`config/filesystems.php`) |
| `path` | string | Путь хранения на диске (не полный URL) |
| `original_name` | string \| null | Имя файла |
| `mime` | string \| null | MIME |
| `size` | int | Размер в байтах |
| `download_url` | string | Абсолютный **временный** подписанный URL (**GET**, без заголовка `Authorization`). Содержит query-параметры `expires` и `signature`. После истечения срока — **403**; запросите сообщения снова, чтобы получить новый URL. TTL задаётся `config/messenger.php` → `attachment_download_ttl_minutes` (env `MESSENGER_ATTACHMENT_DOWNLOAD_TTL`, по умолчанию 60 минут). |

Поля `disk` и `path` по-прежнему отражают хранилище на сервере; для скачивания клиентам следует использовать **`download_url`**.

#### Скачивание вложения

**`GET`** по значению `download_url` из JSON (полный URL с подписью).

- **Авторизация Bearer не требуется** — доступ обеспечивает корректная подпись и срок `expires`.
- Успех: **200**, тело — файл, заголовки `Content-Type` и `Content-Disposition: attachment` (имя файла из `original_name`, при отсутствии — из пути).
- **403** — подпись недействительна или срок истёк.
- **404** — вложение или файл на диске отсутствует.
- Лимит запросов: throttle на маршруте (см. `routes/api.php`).

### Сводка чата (элемент списка диалогов)

Поля совпадают с детализацией, кроме блока `participants` (только в `GET .../conversations/{id}`).

| Поле | Тип | Описание |
|------|-----|----------|
| `id` | int | |
| `type` | string | `direct` \| `group` \| `ai` |
| `title` | string \| null | Для группы; для direct обычно `null` |
| `retention_days` | int \| null | `null` — бессрочно (без прунинга по дням) |
| `created_at`, `updated_at` | string \| null | ISO 8601 |
| `unread_count` | int | Непрочитанные для текущего пользователя (без учёта собственных сообщений) |
| `notifications_muted` | bool | Mute уведомлений по этому чату |
| `mute_until` | string \| null | ISO 8601; если в будущем используется — не слать push до наступления |
| `last_message` | object \| null | Тот же формат, что `message`, или `null` |
| `direct_peer` | object \| отсутствует | Только для `type=direct`: `{ id, name }` — второй участник |
| `ai_server_model_id` | int \| null | Только для `type=ai`: серверная модель (взаимоисключающе с `user_ai_connection_id`) |
| `user_ai_connection_id` | int \| null | Только для `type=ai`: BYOK-подключение пользователя |

### Деталь чата (`GET .../conversations/{id}`)

Все поля сводки **плюс**:

| Поле | Тип | Описание |
|------|-----|----------|
| `participants` | array | `[{ id, name }, ...]` |

---

## Эндпоинты

### Предпочтения уведомлений (глобально)

#### `GET /api/messenger/preferences`

**Ответ 200**

```json
{
  "data": {
    "push_enabled": true
  }
}
```

#### `PATCH /api/messenger/preferences`

**Тело**

| Поле | Тип | Обязательно |
|------|-----|-------------|
| `push_enabled` | bool | да |

**Ответ 200** — тот же формат, что у `GET`.

---

### Список чатов

#### `GET /api/messenger/conversations`

**Ответ 200**

```json
{
  "data": [ /* массив сводок чатов, см. выше */ ]
}
```

Сортировка: по времени последнего сообщения (и `updated_at` чата) — как в `MessengerService::listConversationsSummary`.

---

### Создать чат

#### `POST /api/messenger/conversations`

**Тело (JSON)**

| Поле | Тип | Условие |
|------|-----|---------|
| `type` | string | Обязательно: `direct` \| `group` \| `ai` |
| `user_id` | int | Обязательно при `type=direct` — второй участник (не сам пользователь) |
| `title` | string | Обязательно при `type=group` (непустая строка после trim) и при `type=ai` (до 255 символов) |
| `user_ids` | int[] | Опционально при `type=group` — id дополнительных участников (создатель не дублируется) |
| `ai_server_model_id` | int \| null | Только `type=ai`: задать **ровно одно** из `ai_server_model_id` и `user_ai_connection_id` — активная серверная модель |
| `user_ai_connection_id` | int \| null | Только `type=ai`: **ровно одно** с предыдущим — своё активное BYOK-подключение |

**Поведение**

- **Direct:** если чат пары уже есть — возвращается **тот же** чат (идемпотентность по паре). HTTP **201**.
- **Group:** создатель получает роль `owner`, указанные пользователи — `member`. Несуществующий `user_id` в `user_ids` → **404** с текстом про пользователей.
- **AI:** при выключенном мастер-флаге ИИ (`AI_MASTER_ENABLED=false` / `config('ai.enabled')`) → **422**, поле `type`: «AI is disabled.» При включённом флаге создаётся чат с одним участником (создатель = `owner`), в JSON детали/сводки заполняются `ai_server_model_id` и/или `user_ai_connection_id`. Неверная комбинация идентификаторов или неактивная модель → **422** с соответствующими полями. Смена **`retention_days`** для AI-чата → **422**, поле `retention_days`: «Retention for AI chats is not supported yet.»

**Ответ 201**

```json
{
  "data": { /* деталь чата */ }
}
```

---

### Карточка чата

#### `GET /api/messenger/conversations/{conversation}`

`{conversation}` — числовой id.

**Ответ 200** — `{ "data": { ... деталь чата ... } }`.

**403** — не участник.

---

### Обновить чат

#### `PATCH /api/messenger/conversations/{conversation}`

**Тело (JSON)** — все поля опциональны, обрабатываются только переданные:

| Поле | Тип | Правила |
|------|-----|---------|
| `retention_days` | int \| null | `1…65535` или `null`. **Группа:** только владелец (`owner`). **Direct:** любой участник. **AI:** **422** — retention пока не поддержан (см. текст ошибки выше) |
| `title` | string \| null | Только **группа**; только **owner** |
| `add_user_ids` | int[] | Только **группа**; только **owner**; добавление новых участников |

При смене `retention_days` в direct второму участнику рассылается событие (см. WebSocket) и логика push на стороне сервера.

**Ответ 200** — `{ "data": { ... деталь чата } }`.

**403** — нет права на операцию (например не owner для title / retention в группе).

---

### История сообщений

#### `GET /api/messenger/conversations/{conversation}/messages`

**Query**

| Параметр | Тип | Описание |
|----------|-----|----------|
| `per_page` | int | По умолчанию `50`, максимум `100` |
| `before_id` | int | Сообщения **старше** id (пагинация «вверх по истории») |
| `after_id` | int | Сообщения **новее** id (догон после WS / long poll) |

Нельзя передавать **одновременно** `before_id` и `after_id` → **422** с `{ "message": "Use only one of before_id or after_id." }`.

**Поведение по умолчанию** (без курсоров): последние `per_page` сообщений, отсортированные по `id` по возрастанию в массиве `data`.

**Ответ 200**

```json
{
  "data": [ /* сообщения */ ],
  "meta": {
    "has_more": true,
    "next_before_id": 123,
    "next_after_id": null
  }
}
```

- При догоне вперёд (`after_id`): заполняется `next_after_id`, `next_before_id` = `null`.
- При листании назад (`before_id` или первая страница): заполняется `next_before_id`, `next_after_id` = `null`.

---

### Отправить сообщение

#### `POST /api/messenger/conversations/{conversation}/messages`

Поддерживается **JSON** и **`multipart/form-data`**.

**Поля**

| Поле | Тип | Описание |
|------|-----|----------|
| `body` | string | Опционально; может быть подписью к пересылке |
| `client_message_id` | UUID string | Опционально; идемпотентность |
| `forward_from_message_id` | int | Опционально; пересылка из чата, где пользователь тоже участник |
| `attachments` | файлы | Только для обычной отправки; при пересылке файлы **запрещены** (422) |

Нужно хотя бы одно из: непустой `body`, вложения, или `forward_from_message_id`.

**Идемпотентность `client_message_id`**

- Повтор с тем же UUID в **том же** чате возвращает **существующее** сообщение (**201** с тем же телом).
- Тот же UUID в **другом** чате → **422**.

**Ответ 201**

```json
{
  "data": { /* message */ }
}
```

Ошибки валидации вложений (количество, размер, MIME) — **422**, ключи вида `attachments` / `attachments.0` (см. `config/messenger.php` и переменные окружения `MESSENGER_*`).

**Чаты `type=ai`:** после успешного **текстового** сообщения пользователя (без вложений, не пересылка) сервер ставит в очередь job **`ProcessAiChatReplyJob`**. **До** записи сообщения выполняется предпроверка квот для **серверной** модели и BYOK rate limit; при отказе — **402**/**403** и стабильное тело `{ code, message }` (см. таблицу выше), **сообщение пользователя не создаётся**. Если сообщение уже принято, а ошибка возникает при вызове провайдера (сеть, 5xx провайдера и т.д.), в чат по-прежнему может быть записано **системное** сообщение, а HTTP на исходный `POST` уже **201**.

Ответ модели приходит отдельным сообщением с `user_id: null` и событием **`messenger.message.sent`**. Для ответов ассистента и системных сообщений об ошибке этот broadcast выполняется **сразу** (`shouldBroadcastNow`), без постановки отдельного `BroadcastEvent` в очередь — клиенты Echo получают событие сразу после завершения job. Обычные сообщения пользователей по-прежнему уходят в broadcast через очередь (если настроена). На продакшене нужен **воркер** на очередь, где крутится `ProcessAiChatReplyJob`; при `sync` job выполняется в том же PHP-процессе. При ошибке вызова провайдера в чат может быть записано системное сообщение (и запись в журнале запросов ИИ — см. Moonshine).

---

### Прочитано

#### `POST /api/messenger/conversations/{conversation}/read`

**Тело (JSON)**

| Поле | Тип |
|------|-----|
| `message_id` | int, обязательно |

Сообщение должно принадлежать этому чату; иначе **422**.

**Ответ 200**

```json
{ "ok": true }
```

Если новое значение не выше уже сохранённого `last_read_message_id`, broadcast может не отправляться.

---

### Присутствие в чате (foreground)

#### `POST /api/messenger/conversations/{conversation}/presence`

Клиент вызывает **периодически**, пока пользователь **смотрит этот чат** (приложение на переднем плане). Пока отметка в кэше актуальна, сервер **не шлёт push** этому пользователю о новых сообщениях **в этом же** чате.

**Тело (JSON)**

| Поле | Тип | По умолчанию |
|------|-----|----------------|
| `foreground` | bool | `true` — обновить отметку; `false` — сбросить presence |

**Ответ 200:** `{ "ok": true }`.

TTL: `config('messenger.presence_ttl_seconds')` (env **`MESSENGER_PRESENCE_TTL`**, по умолчанию 60 с). Интервал heartbeat на клиенте должен быть **меньше** TTL.

**403** — не участник чата.

---

### Уведомления по чату (mute)

#### `PATCH /api/messenger/conversations/{conversation}/notifications`

**Тело (JSON)**

| Поле | Тип |
|------|-----|
| `notifications_muted` | bool, обязательно |
| `mute_until` | string (дата) \| опционально, nullable |

**Ответ 200**

```json
{
  "data": {
    "notifications_muted": false,
    "mute_until": null
  }
}
```

`mute_until` в ответе — ISO 8601 строка или `null`.

---

### Регистрация push-токена устройства

#### `POST /api/devices/push-token`

Не внутри префикса `messenger`, но часть сценария мессенджера.

**Тело (JSON)**

| Поле | Тип |
|------|-----|
| `token` | string, обязательно, max 512 |
| `platform` | `ios` \| `android`, обязательно |
| `app_version` | string, опционально, max 64 |

- **`android`:** токен регистрации **FCM** (сервер шлёт через legacy FCM HTTP при настроенном `FCM_LEGACY_SERVER_KEY`).
- **`ios`:** нативный **device token APNs** (обычно 64 hex-символа без пробелов; сервер нормализует регистр и лишние символы). Отправка при настроенных `APNS_*` — см. **`.cursor/docs/messenger-push-apns.md`**.

Токен уникален глобально: при повторной регистрации обновляется привязка к текущему пользователю.

**Ответ 200**

```json
{ "ok": true }
```

---

## Скилы в AI-чате

Префикс тот же: `/api/messenger`. Все маршруты ниже защищены middleware **`ai.enabled`**: при выключенном ИИ — **503**, тело `{ "code": "ai_disabled", "message": "AI features are disabled." }`.

Доступ только к чатам, где участник — текущий пользователь, и **`type=ai`**. Для чата не-AI — **422**, поле `conversation`: «Skills are only available for AI conversations.»

| Метод | Путь | Описание |
|--------|------|----------|
| `GET` | `/conversations/{id}/skills` | Список скилов чата |
| `POST` | `/conversations/{id}/skills` | Создать: `title`, `instruction_text`, опционально `enabled`, `sort_order` |
| `PATCH` | `/conversations/{id}/skills/{skillId}` | Обновить поля; **только скилы с `user_id` текущего пользователя** |
| `DELETE` | `/conversations/{id}/skills/{skillId}` | Удалить свой скил |

**Объект скилла** в `data` (и в элементах списка):

| Поле | Тип |
|------|-----|
| `id` | int |
| `user_id` | int |
| `conversation_id` | int |
| `title` | string |
| `instruction_text` | string |
| `enabled` | bool |
| `sort_order` | int |
| `created_at`, `updated_at` | ISO 8601 |

Превышение лимита скилов на чат — **422**, поле `conversation`: «Maximum {N} skills per conversation.»  
`PATCH`/`DELETE` чужого скилла — **403** «You can only change your own skills.»

Лимит числа скилов на чат — `config('ai.max_skills_per_conversation')` (env `AI_MAX_SKILLS_PER_CONVERSATION` при наличии в конфиге).

---

## API ИИ (`/api/ai`)

Базовый путь: **`/api/ai`**. Авторизация: как у остального API (**Bearer**). Middleware **`ai.enabled`**: при `AI_MASTER_ENABLED=false` — **503** с `code: ai_disabled` (создание AI-чата через `POST .../messenger/conversations` при этом отдаёт **422** на поле `type` — см. выше).

### `GET /api/ai/server-models`

**200** — список **активных** моделей с активным провайдером. Если у пользователя **активная подписка** в БД и в тарифе задан `limits.allowed_ai_server_model_ids`, в ответ попадают **только** перечисленные `id` (пустой массив в тарифе → пустой `data`).

### `GET /api/ai/subscription`

**Query (опционально):** `ai_server_model_id` (int) — уточнить `client_hints.server_ai_available` для конкретной серверной модели (квота + входит ли модель в тариф).

**200** — текущая подписка, лимиты и **квота на сегодня** (граница суток — `billing.quota_timezone`, по умолчанию Europe/Moscow):

- `preferences.max_requests_per_day_self` — добровольный дневной потолок (`null` = не задан).
- `server_ai.server_requests_used_today`, `server_requests_daily_effective_limit` (`null` = без лимита), `server_requests_remaining_today` (`null` если лимита нет), `server_side_daily_ceiling` (потолок **без** учёта self-cap), месячные токены (`server_tokens_monthly_cap`, `server_tokens_used_this_month`, …).
- `subscription.tier` при активной подписке может включать `price_monthly_rub`, поля скидки (`discount_*`), лимиты (`tools_enabled`, `max_ai_chats`, `server_tokens_per_month`).
- **`client_hints`:** `needs_subscription` (bool) — для серверного ИИ нет бесплатной квоты/триала и нужна оплата; `server_ai_available` (bool) — пройдут ли проверки **сейчас** (без `ai_server_model_id` — базовая квота; с параметром — с учётом allowlist модели).

### `PATCH /api/ai/preferences`

Тело JSON: поле **`max_requests_per_day_self`** — если **нет в теле**, ответ **200** с текущим значением без изменений в БД. Если ключ **есть**: **nullable** целое ≥ 1 (для сброса ограничения передать `null`). Значение **не может превышать** дневной потолок тарифа/триала (`server_side_daily_ceiling`); при «безлимитном» тарифе сверху действует `billing.max_self_cap_requests_per_day` (env `BILLING_AI_MAX_SELF_CAP_PER_DAY`).

**422** — если self-cap выше допустимого.

**200** — `{ "data": { "max_requests_per_day_self": ... } }`.

**Пример ответа** (когда тариф **не** сужает список моделей):

```json
{
  "data": [
    {
      "id": 1,
      "display_name": "GPT-4o mini",
      "vendor_model_id": "gpt-4o-mini",
      "provider": { "id": 1, "name": "OpenAI", "driver": "openai" }
    },
    {
      "id": 2,
      "display_name": "Groq Llama",
      "vendor_model_id": "llama-3.1-8b-instant",
      "provider": { "id": 2, "name": "Groq", "driver": "openai_compatible" }
    }
  ]
}
```

Поле **`provider.driver`** отражает значение из БД; клиентам достаточно знать, что оба поддерживаемых ключа ведут себя как OpenAI-compatible HTTP (см. таблицу драйверов выше).

### Подключения пользователя (BYOK)

| Метод | Путь | Описание |
|--------|------|----------|
| `GET` | `/api/ai/connections` | Список своих подключений |
| `POST` | `/api/ai/connections` | Создать: `name`, `driver`, `credentials` (массив), опционально `enabled` |
| `PATCH` | `/api/ai/connections/{id}` | Частичное обновление |
| `DELETE` | `/api/ai/connections/{id}` | Удалить |

**Валидация:** `driver` — только значения из **`AiChatDrivers`** (текущие ключи см. `config/ai.php` → `chat_drivers`).

**`credentials`** (ассоциативный массив, ожидаемые ключи при вызове чата):

| Ключ | Обязательность | Описание |
|------|----------------|----------|
| `api_key` или `openai_api_key` | Обязателен хотя бы один с непустой строкой | Секрет для заголовка авторизации у провайдера |
| `base_url` | Опционально | База до `/chat/completions` (как у OpenAI, обычно заканчивается на `/v1`); иначе `config('ai.openai.base_url')` |
| `model` | Опционально | Идентификатор модели у вендора; если пусто — в коде подставляется `gpt-4o-mini` |

В ответах **не** отдаётся полный секрет: есть **`key_hint`** (маска), плюс `id`, `name`, `driver`, `enabled`, `last_used_at`, даты создания/обновления. Политика доступа — `UserAiConnectionPolicy`.

**`DELETE`:** ответ **200** `{ "ok": true }`.

Серверные вызовы для чатов с **`ai_server_model_id`** используют ключ из `ai_providers.config` и/или env **`AI_OPENAI_SERVER_API_KEY`** (см. `config/ai.php` и OpenAI-совместимый клиент в `App\Services\Ai`).

### Напоминания и расписание (агент, §11)

Создание через **tools** в AI-чате (`schedule_reminder`, `create_task_with_deadline`, `link_event_booking_reminder`) — см. **`.cursor/docs/agent-tools.md`**.

| Метод | Путь | Описание |
|--------|------|----------|
| `GET` | `/api/ai/scheduled-items` | Список своих записей (до 200), middleware **`ai.enabled`** |
| `DELETE` | `/api/ai/scheduled-items/{id}` | Удалить свою запись |

Доставка: команда **`ai:process-scheduled-items`** (по умолчанию каждую минуту в scheduler) + очередь; push и письмо — см. доку агента.

---

## Конфигурация лимитов (сервер)

Файл `config/messenger.php`, переопределение через `.env`:

| Ключ env | Назначение |
|----------|------------|
| `MESSENGER_MAX_ATTACHMENT_BYTES` | Максимальный размер файла (байты), пусто = без лимита |
| `MESSENGER_ALLOWED_MIMES` | Список MIME через запятую; пусто = без whitelist |
| `MESSENGER_MAX_ATTACHMENTS_PER_MESSAGE` | Лимит числа файлов за раз |
| `MESSENGER_ATTACHMENT_DOWNLOAD_TTL` | Срок жизни подписанного URL скачивания (минуты) |

### ИИ (`config/ai.php`)

| Ключ env | Назначение |
|----------|------------|
| `AI_MASTER_ENABLED` | Глобальное включение ИИ (`config('ai.enabled')`) |
| `AI_OPENAI_SERVER_API_KEY` | Ключ для серверных моделей, если не задан в `ai_providers.config` |
| `AI_REQUEST_LOG_RETENTION_DAYS` | Хранение строк в `ai_request_logs` (планировщик: `ai:prune-request-logs`) |
| `AI_PROMPT_EXCERPT_MAX` / `AI_RESPONSE_EXCERPT_MAX` | Обрезка текста в журнале |

Квоты **серверных** запросов к ИИ (триал, неплатящий дневной лимит, подписка) описаны в **`.cursor/docs/ai-billing.md`**. BYOK на эти лимиты не распространяется.

Для локальной демонстрации без ручного ввода в БД: **`php artisan db:seed --class=AiDemoSeeder`** (только окружение **`local`**).

---

## Реальное время (Laravel Reverb / Echo)

Приватный канал (имя для Echo/Pusher-совместимых клиентов):

```text
private-messenger.conversation.{conversationId}
```

Авторизация канала: стандартный Laravel endpoint **`/broadcasting/auth`** с сессией или токеном Sanctum (в проекте для broadcasting указаны middleware `web`, `auth:sanctum` — уточните для нативных клиентов способ подписи: cookie vs Bearer в теле запроса к `/broadcasting/auth`).

### События

| Broadcast name (клиент слушает) | Payload |
|----------------------------------|---------|
| `messenger.message.sent` | `{ "message": { ... } }` — формат как в REST; для ответов ИИ и системных ошибок в AI-чате доставка **синхронная** относительно job (см. выше) |
| `messenger.read.updated` | `{ "conversation_id", "user_id", "last_read_message_id" }` |
| `messenger.conversation.updated` | `{ "conversation_id", "retention_days", "changed_by_user_id", "notify_user_id" }` — смена срока хранения и др. |

После переподключения WS клиенту следует вызвать **`GET .../messages?after_id=`** с последним известным `id` сообщения.

---

## Надёжность (рекомендации клиентам)

1. **Повторы POST** сообщений: использовать **`client_message_id`** (UUID v4).
2. **Потеря WS:** периодический опрос списка чатов и/или `messages?after_id=`.
3. **Backoff** на сетевые ошибки и 5xx.
4. **Базовый URL:** список IP по приоритету и fallback `https://m-engine.ru` (см. план §12).

---

## Что ещё не в API (ожидается по дорожной карте)

- Явное **версионирование** путей (`/api/messenger/v1/...`).
- Опционально: дублировать **`ai_enabled`** в `GET /api/user` после логина (глобальный флаг уже в **`GET /api/features`**).
- Дополнительно: **стабильный путь** скачивания вложений с Bearer вместо подписанного GET — при отдельной политике кэширования/CDN.
- **Новые драйверы** с иным протоколом (не OpenAI-compatible) потребуют нового ключа в `chat_drivers` и кода адаптера.

Журнал запросов к ИИ и (при наличии в админке) экспорт CSV — **Moonshine**, не публичный REST для мобильных клиентов.

При изменении полей или маршрутов обновляйте этот файл и по возможности добавляйте тесты в `tests/Feature/Messenger/`.
